int nP(int);
