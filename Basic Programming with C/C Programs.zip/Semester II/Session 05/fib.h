void fib(int);
