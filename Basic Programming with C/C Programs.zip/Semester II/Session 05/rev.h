void rev(int[]);
