/* 3S_revArray.c [L5P3F1] */

#include "rev.h"

int main()

{
                /* Program to print an Array in the reverse order - Client */
                
                int a[10] = {1, 2, 3, 4, 5};
                
                rev(a);

                return 0;
}

/***** END OF FILE *****/
