#include<stdio.h>

int main(void)
{
	printf("%s%s%s%s%s", "#include<stdio.h>\n", "int main()\n{\n", "printf('Hello World\\n');\n", "return 0;\n", "}\n");
	return 0;
}
