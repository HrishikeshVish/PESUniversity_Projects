void rev(char*, char*, int);
int comp(char*, char*, int);
