void conc(char*, char*, int, int);
