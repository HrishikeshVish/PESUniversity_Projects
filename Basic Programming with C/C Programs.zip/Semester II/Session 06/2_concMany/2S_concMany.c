#include "con.h"

int i;

void conc(char* s, char* s1, int n, int n1)
{
for (i = 0; i < n1; i++)
s[n+i] = s1[i];
}
