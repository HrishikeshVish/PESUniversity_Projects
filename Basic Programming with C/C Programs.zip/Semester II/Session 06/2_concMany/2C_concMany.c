#include <stdio.h>
#include <string.h>
#include "con.h"

int main(void)
{
char s[200], s1[100]; int d;
printf("Enter the first string: ");
scanf("%s", s);
printf("Enter the second string: ");
scanf("%s", s1);
int n1 = strlen(s1);
printf("Enter the number of times to replicate the second string: ");
scanf("%d", &d);
int i;
printf("%d", n);
for (i = 0; i < d; i++)
{
int n = strlen(s);
conc(s, s1, n, n1);
}

printf("The concatenated string is %s\n", s);

return 0;
}
