struct Student
{
char Name[100], Div[3], Res;
int SRN, P, C, E, Total;
float Avg;
};

void fill(int, struct Student s[]);
