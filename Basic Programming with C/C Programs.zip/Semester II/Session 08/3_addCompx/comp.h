void add(double, double, double, double, double *, double *);
