#include "comp.h"

void add(double r1, double i1, double r2, double i2, double *rr, double *ir)
{
*rr = r1 + r2;
*ir = i1 + i2;
}
