struct Date
{
int D, M, Y;
}

int comp(struct Date, struct Date);
