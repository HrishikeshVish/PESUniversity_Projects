/* first.c [L1P1F1] */

#include<stdio.h>

int main()

{
	/* My First C Program [At PES University CB Lab] */
	printf("Hello Cruel World!\n");
	return 0.0;
}

/***** END OF FILE *****/
