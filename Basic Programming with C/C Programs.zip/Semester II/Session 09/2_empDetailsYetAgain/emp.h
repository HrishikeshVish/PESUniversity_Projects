struct employee

{

    int SSN;
    char Name[100];
    char Dept[10];

};

void readData(int, struct employee*);
void dispData(int, struct employee*);
