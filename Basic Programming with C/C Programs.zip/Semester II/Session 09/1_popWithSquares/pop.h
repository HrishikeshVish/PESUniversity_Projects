void readArray(int, int*);
void popsArray(int, int*);
void readArray(int, int*);
