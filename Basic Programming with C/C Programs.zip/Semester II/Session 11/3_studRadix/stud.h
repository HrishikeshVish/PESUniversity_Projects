struct student

{
    int roll;
    char name[100];
};

void radixSort(int, struct student *);
