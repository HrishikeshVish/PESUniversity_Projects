#include <stdio.h>
//#include "iden.h"

int main()
{
int n, i, j;
printf("Enter the order of the matrix: ");
scanf("%d", &n);
int a[10][10] = {};
for(i = 0; i < n; i++)
a[i][i] = 1;
for(i=0; i<n; i++)
{
for(j=0; j<n; j++)
printf("%d\t", a[i][j]);
putchar('\n');
}
getchar();
return 0;
}
