void sum(int m, int n, int a[m][n], int b[m][n], int r[m][n]);
