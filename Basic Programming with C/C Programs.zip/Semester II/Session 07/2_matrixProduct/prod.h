void prod(int m1, int n1, int m2, int n2, int a[m1][n1], int b[m2][n2], int r[m1][n2]);
